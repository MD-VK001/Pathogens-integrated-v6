# Pathogen Guide v6.0 — GitHub phone build

This package is prepared for building the native Kotlin Android project on GitHub Actions without a desktop computer.

## What is included

- `project/PathogenGuide-Kotlin-native-v6.0.zip` — the complete native Android/Kotlin project.
- `.github/workflows/build-apk.yml` — GitHub Actions workflow that extracts the ZIP, installs Android SDK 35, uses Java 17 + Gradle 8.10.2, and builds the APK.

## Easiest phone-only setup

GitHub's normal web uploader does not reliably extract a ZIP into the repository. The simplest approach is:

1. Create a new GitHub repository.
2. Upload `project/PathogenGuide-Kotlin-native-v6.0.zip` to the repository. You may put it in the repository root; the workflow searches for this filename.
3. In GitHub, choose **Add file → Create new file**.
4. Set the filename to:
   `.github/workflows/build-apk.yml`
5. Open the supplied `build-apk.yml` from this package and copy its entire contents into that GitHub file.
6. Commit the file to the `main` branch.
7. The workflow will run automatically. You can also open **Actions → Build Pathogen Guide APK → Run workflow**.
8. When it finishes, open the workflow run and download the artifact named:
   `PathogenGuide-v6.0-debug-apk`

## Important

Do NOT upload the outer preparation package as the only repository file and expect GitHub Actions to see the workflow inside it. GitHub Actions only recognizes workflow YAML files that physically exist under `.github/workflows/` in the repository.

The project itself remains a ZIP so that the entire source can be uploaded from an Android phone without manually selecting hundreds of files.
